# Hook

This is the corrected Hook Android project.

Important:
- The app package is `com.hook.app`.
- The Firebase configuration is included in `app/google-services.json`.
- The Android UI is in `app/src/main/assets/index.html`.
- This ZIP is intentionally flattened so the Android project is directly under the extracted folder.

For the GitHub Actions workflow, upload this ZIP to the repository root and use the supplied workflow logic so the correct project is extracted before building.
