# بناء Hook من الهاتف عبر GitHub

1. أنشئ مستودع GitHub جديدًا.
2. ارفع محتويات هذا المجلد إلى المستودع (وليس ملف ZIP نفسه).
3. افتح تبويب Actions.
4. اختر Build Hook APK.
5. اضغط Run workflow.
6. بعد انتهاء البناء، افتح نتيجة التشغيل وحمّل Artifact باسم Hook-debug-apk.
7. فك الضغط عن الـArtifact وستجد app-debug.apk.

هذه نسخة Debug للتجربة على الهاتف.
